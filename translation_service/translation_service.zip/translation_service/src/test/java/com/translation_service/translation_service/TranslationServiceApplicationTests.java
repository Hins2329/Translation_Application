package com.translation_service.translation_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranslationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
